package com.example.demo.controller;

import com.example.demo.model.Repository;
import com.example.demo.repository.IRepositoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.List;

@RestController
@RequestMapping("/repositories")
@RequiredArgsConstructor
public class RepositoryController {

    private final IRepositoryRepository repositoryRepository;

    @GetMapping
    public List<Repository> findAllRepositories() {
        return repositoryRepository.findAll();
    }

    // Consulta 2 — date con formato "yyyy-MM-dd HH:mm:ss"
    @GetMapping("/derived")
    public List<Repository> findDerivedByTeacherEmailAndDeadline(@RequestParam("email") String email,
                                                                 @RequestParam("date") String date) {
        return repositoryRepository
                .findByParentRepoIsNotNullAndAssignment_Classroom_Teacher_EmailAndAssignment_DeadlineAfter(
                        email, Timestamp.valueOf(date));
    }
}
