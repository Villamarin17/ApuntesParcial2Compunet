package com.example.demo.repository;

import com.example.demo.model.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IAssignmentRepository extends JpaRepository<Assignment, Long> {

    // Consulta 5: assignments del docente (username) con repos que tienen PRs
    // revisados por un revisor (username) y con un status dado. Distinct evita duplicados.
    List<Assignment> findDistinctByClassroom_Teacher_UsernameAndRepositories_PullRequests_Reviewer_UsernameAndRepositories_PullRequests_Status(
            String teacherUsername, String reviewerUsername, String status);
}
