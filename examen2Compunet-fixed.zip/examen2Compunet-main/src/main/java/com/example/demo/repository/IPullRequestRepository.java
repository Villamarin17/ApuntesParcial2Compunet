package com.example.demo.repository;

import com.example.demo.model.PullRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IPullRequestRepository extends JpaRepository<PullRequest, Long> {

    // Consulta 1: PRs de un Classroom (por nombre) con un status, ordenados por fecha desc
    List<PullRequest> findByRepository_Assignment_Classroom_NameAndStatusOrderByCreatedAtDesc(
            String classroomName, String status);

    // Consulta 3: PRs cuyo revisor tiene un rol, autor con username dado y Classroom de un semestre
    List<PullRequest> findByReviewer_RoleAndAuthor_UsernameAndRepository_Assignment_Classroom_Semester(
            String reviewerRole, String authorUsername, String semester);
}
