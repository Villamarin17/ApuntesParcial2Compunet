package com.example.demo.repository;

import com.example.demo.model.Commit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ICommitRepository extends JpaRepository<Commit, Long> {

    // Consulta 4: commits en repos derivados de una plantilla (por nombre), mensaje contiene
    // palabra clave (ignore case) y linesAdded estrictamente mayor a un valor
    List<Commit> findByRepository_ParentRepo_NameAndMessageContainingIgnoreCaseAndLinesAddedGreaterThan(
            String templateName, String keyword, Integer minLines);
}
