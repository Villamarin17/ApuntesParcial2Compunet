package com.example.demo.repository;

import com.example.demo.model.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Timestamp;
import java.util.List;

public interface IRepositoryRepository extends JpaRepository<Repository, Long> {

    // Consulta 2: repos derivados (parentRepo no nulo) cuyo docente titular tiene un email
    // y cuya assignment tiene deadline posterior a una fecha
    List<Repository> findByParentRepoIsNotNullAndAssignment_Classroom_Teacher_EmailAndAssignment_DeadlineAfter(
            String teacherEmail, Timestamp date);
}
